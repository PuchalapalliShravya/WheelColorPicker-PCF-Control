var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./WheelColorPickControl/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./WheelColorPickControl/index.ts":
/*!****************************************!*\
  !*** ./WheelColorPickControl/index.ts ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar WheelColorPickControl =\n/** @class */\nfunction () {\n  function WheelColorPickControl() {\n    this._canPreview = false;\n  }\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='starndard', it will receive an empty div element within which it can render its content.\r\n   */\n\n\n  WheelColorPickControl.prototype.init = function (context, notifyOutputChanged, state, container) {\n    this._context = context;\n    this._notifyOutputChanged = notifyOutputChanged; // @ts-ignore       \n\n    this._colorPropertyFieldName = this._context.parameters.ColorProperty.attributes.LogicalName; // @ts-ignore \n\n    this._colorPropertyFieldValue = Xrm.Page.getAttribute(this._colorPropertyFieldName).getValue();\n    this._container = document.createElement(\"div\");\n    this.buildColorPickerCode();\n    container.appendChild(this._container);\n  };\n  /**\r\n   * Build UI to display Color.\r\n   */\n\n\n  WheelColorPickControl.prototype.buildColorPickerCode = function () {\n    this._previewDivContainer = document.createElement(\"div\");\n\n    this._previewDivContainer.setAttribute(\"class\", \"preview\");\n\n    this._previewDivContainer.setAttribute(\"id\", \"preview\");\n\n    this._previewDivContainer.addEventListener(\"click\", this.onClickOfPreview.bind(this));\n\n    this._container.append(this._previewDivContainer);\n\n    this._canvasElement = this.generateColorWheel(200, \"white\"); //Wheel size and Center color of wheel\n\n    this._canvasElement.setAttribute(\"class\", \"rotate\");\n\n    this._canvasElement.addEventListener(\"mousemove\", this.onMouseHover.bind(this));\n\n    this._canvasElement.addEventListener(\"click\", this.onClickOfCanvas.bind(this));\n\n    this._colorPickerDivContainer = document.createElement(\"div\");\n\n    this._colorPickerDivContainer.setAttribute(\"class\", \"colorpicker\");\n\n    this._colorPickerDivContainer.appendChild(this._canvasElement);\n\n    if (this._colorPropertyFieldValue) this._previewDivContainer.style.backgroundColor = this._colorPropertyFieldValue;\n\n    this._container.append(this._colorPickerDivContainer);\n  };\n  /**\r\n   * On click of Color Canvas switch between Color freezing and Color Selection.\r\n   */\n\n\n  WheelColorPickControl.prototype.onClickOfCanvas = function (e) {\n    this._canPreview = !this._canPreview;\n\n    this._notifyOutputChanged();\n  };\n  /**\r\n   * On click of UI element for Color hide and show Canvas.\r\n   */\n\n\n  WheelColorPickControl.prototype.onClickOfPreview = function (e) {\n    if (!this._canPreview) {\n      this._canPreview = true;\n      this._colorPickerDivContainer.style.display = \"block\";\n    } else {\n      this._canPreview = false;\n      this._colorPickerDivContainer.style.display = \"none\";\n    }\n\n    this._notifyOutputChanged();\n  };\n  /**\r\n   * Update the record with the selected Color.\r\n   */\n\n\n  WheelColorPickControl.prototype.onMouseHover = function (evt) {\n    if (this._canPreview) {\n      var imgData = void 0;\n\n      var ctx = this._canvasElement.getContext(\"2d\");\n\n      if (ctx) imgData = ctx.getImageData(evt.offsetX, evt.offsetY, 1, 1);\n      var pixel = imgData.data;\n      var dColor = pixel[2] + 256 * pixel[1] + 65536 * pixel[0];\n      var hexColor = '#' + ('0000' + dColor.toString(16)).substr(-6);\n      this._previewDivContainer.style.backgroundColor = hexColor;\n      this._colorPropertyFieldValue = hexColor; // @ts-ignore \n\n      Xrm.Page.getAttribute(this._colorPropertyFieldName).setValue(hexColor);\n    }\n  };\n  /**\r\n   * Convert Degree to Radians.\r\n   */\n\n\n  WheelColorPickControl.prototype.degreesToRadians = function (degrees) {\n    return degrees * (Math.PI / 180);\n  };\n  /**\r\n   * Generate Color Wheel.\r\n   */\n\n\n  WheelColorPickControl.prototype.generateColorWheel = function (size, centerColor) {\n    if (size === void 0) {\n      size = 400;\n    }\n\n    if (centerColor === void 0) {\n      centerColor = \"white\";\n    } //Generate main canvas to return\n\n\n    var canvas = document.createElement(\"canvas\");\n    var ctx = canvas.getContext(\"2d\");\n    canvas.width = canvas.height = size; //Generate canvas clone to draw increments on\n\n    var canvasClone = document.createElement(\"canvas\");\n    canvasClone.width = canvasClone.height = size;\n    var canvasCloneCtx = canvasClone.getContext(\"2d\"); //Initiate variables\n\n    var angle = 0;\n    var hexCode = [255, 0, 0];\n    var pivotPointer = 0;\n    var colorOffsetByDegree = 4.322; //For each degree in circle, perform operation\n\n    while (angle++ < 360) {\n      //find index immediately before and after our pivot\n      var pivotPointerbefore = (pivotPointer + 3 - 1) % 3; //Modify colors\n\n      if (hexCode[pivotPointer] < 255) {\n        //If main points isn't full, add to main pointer\n        hexCode[pivotPointer] = hexCode[pivotPointer] + colorOffsetByDegree > 255 ? 255 : hexCode[pivotPointer] + colorOffsetByDegree;\n      } else if (hexCode[pivotPointerbefore] > 0) {\n        //If color before main isn't zero, subtract\n        hexCode[pivotPointerbefore] = hexCode[pivotPointerbefore] > colorOffsetByDegree ? hexCode[pivotPointerbefore] - colorOffsetByDegree : 0;\n      } else if (hexCode[pivotPointer] >= 255) {\n        //If main color is full, move pivot\n        hexCode[pivotPointer] = 255;\n        pivotPointer = (pivotPointer + 1) % 3;\n      }\n\n      if (canvasCloneCtx && ctx != null) //clear clone\n        {\n          canvasCloneCtx.clearRect(0, 0, size, size); //Generate gradient and set as fillstyle\n\n          var grad = canvasCloneCtx.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);\n          grad.addColorStop(0, centerColor);\n          grad.addColorStop(1, \"rgb(\" + hexCode.map(function (h) {\n            return Math.floor(h);\n          }).join(\",\") + \")\");\n          canvasCloneCtx.fillStyle = grad; //draw full circle with new gradient\n\n          canvasCloneCtx.globalCompositeOperation = \"source-over\";\n          canvasCloneCtx.beginPath();\n          canvasCloneCtx.arc(size / 2, size / 2, size / 2, 0, Math.PI * 2);\n          canvasCloneCtx.closePath();\n          canvasCloneCtx.fill(); //Switch to \"Erase mode\"\n\n          canvasCloneCtx.globalCompositeOperation = \"destination-out\"; //Carve out the piece of the circle we need for this angle\n\n          canvasCloneCtx.beginPath();\n          canvasCloneCtx.arc(size / 2, size / 2, 0, this.degreesToRadians(angle + 1), this.degreesToRadians(angle + 1));\n          canvasCloneCtx.arc(size / 2, size / 2, size / 2 + 1, this.degreesToRadians(angle + 1), this.degreesToRadians(angle + 1));\n          canvasCloneCtx.arc(size / 2, size / 2, size / 2 + 1, this.degreesToRadians(angle + 1), this.degreesToRadians(angle - 1));\n          canvasCloneCtx.arc(size / 2, size / 2, 0, this.degreesToRadians(angle + 1), this.degreesToRadians(angle - 1));\n          canvasCloneCtx.closePath();\n          canvasCloneCtx.fill(); //Draw carved-put piece on main canvas\n\n          ctx.drawImage(canvasClone, 0, 0);\n        }\n    } //return main canvas\n\n\n    return canvas;\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n\n\n  WheelColorPickControl.prototype.updateView = function (context) {\n    // @ts-ignore \n    Xrm.Page.getAttribute(this._colorPropertyFieldName).setValue(this._colorPropertyFieldValue);\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n\n\n  WheelColorPickControl.prototype.getOutputs = function () {\n    var result = {\n      ColorProperty: this._colorPropertyFieldValue\n    };\n    return result;\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n\n\n  WheelColorPickControl.prototype.destroy = function () {\n    this._canvasElement.removeEventListener(\"mousemove\", this.onMouseHover);\n\n    this._canvasElement.removeEventListener(\"click\", this.onClickOfCanvas);\n\n    this._previewDivContainer.removeEventListener(\"click\", this.onClickOfPreview);\n  };\n\n  return WheelColorPickControl;\n}();\n\nexports.WheelColorPickControl = WheelColorPickControl;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./WheelColorPickControl/index.ts?");

/***/ })

/******/ });
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('CustomControls.WheelColorPickControl', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.WheelColorPickControl);
} else {
	var CustomControls = CustomControls || {};
	CustomControls.WheelColorPickControl = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.WheelColorPickControl;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}